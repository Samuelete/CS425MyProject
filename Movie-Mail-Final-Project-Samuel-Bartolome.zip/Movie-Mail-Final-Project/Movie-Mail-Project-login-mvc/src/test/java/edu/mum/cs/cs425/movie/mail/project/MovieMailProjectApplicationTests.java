package edu.mum.cs.cs425.movie.mail.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieMailProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
