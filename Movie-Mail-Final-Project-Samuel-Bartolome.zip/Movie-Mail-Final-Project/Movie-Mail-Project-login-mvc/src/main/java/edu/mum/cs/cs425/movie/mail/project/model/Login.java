package edu.mum.cs.cs425.movie.mail.project.model;

public class Login {

}
