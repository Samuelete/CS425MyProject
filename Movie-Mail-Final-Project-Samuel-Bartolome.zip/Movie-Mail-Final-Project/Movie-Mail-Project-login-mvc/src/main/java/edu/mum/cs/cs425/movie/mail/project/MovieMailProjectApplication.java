package edu.mum.cs.cs425.movie.mail.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieMailProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieMailProjectApplication.class, args);
	}

}
