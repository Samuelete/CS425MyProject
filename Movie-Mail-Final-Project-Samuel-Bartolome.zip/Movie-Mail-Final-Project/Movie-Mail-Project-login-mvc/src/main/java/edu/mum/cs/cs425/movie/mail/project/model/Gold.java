package edu.mum.cs.cs425.movie.mail.project.model;

public class Gold extends Subscription {

	@Override
	protected void addDvdHome() {
		// TODO Auto-generated method stub	
	}

}
