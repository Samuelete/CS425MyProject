package edu.mum.cs.cs425.eregistar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ERegistarApplicationTests {

	@Test
	void contextLoads() {
	}

}
